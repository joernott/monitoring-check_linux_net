#!/bin/bash
# see https://github.com/joernott/monitoring-check_linux_net/tags
APP="monitoring-check_linux_net"
VERSION="1.0.1"
RELEASE="1"
URL="https://github.com/joernott/monitoring-check_linux_net/archive/refs/tags/v${VERSION}.tar.gz"
ARCH="noarch"
